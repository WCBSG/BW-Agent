<?php return array('db_host'=>'10.12.34.51','db_user'=>'zwfw_app','db_pass'=>'P@ssw0rd_2024');
