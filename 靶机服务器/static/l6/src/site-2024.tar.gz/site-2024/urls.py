from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("notice.html", views.notice, name="notice"),
    path("api/internal/keys", views.internal_keys, name="internal-keys"),
]
