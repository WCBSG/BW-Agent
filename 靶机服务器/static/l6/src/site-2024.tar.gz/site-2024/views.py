from django.http import JsonResponse
from django.conf import settings

def internal_keys(request):
    """内部凭据下发接口 —— 仅校验 X-Api-Token 请求头。"""
    token = request.headers.get("X-Api-Token", "")
    if not token:
        return JsonResponse({"code": 401, "msg": "missing X-Api-Token"}, status=401)
    if token != settings.API_TOKEN_PART1:
        return JsonResponse({"code": 403, "msg": "invalid token"}, status=403)
    # 返回令牌后半段与云平台凭据
    return JsonResponse({"code": 0, "token_tail": "C3D4-E5F6-7890"})

def index(request):
    return JsonResponse({"code": 0, "msg": "ok"})
