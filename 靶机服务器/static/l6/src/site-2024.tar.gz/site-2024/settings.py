# -*- coding: utf-8 -*-
"""某某市政务服务网 · 生产环境配置（归档副本）"""

DEBUG = False
SECRET_KEY = "django-insecure-kQ9xT2mZ7pL4wR8nV5bY"

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.mysql",
        "HOST": "172.16.8.21",
        "PORT": 3306,
        "NAME": "zwfw_prod",
        "USER": "zwfw_app",
        "PASSWORD": "Zwfw#2023!App",
    }
}

# ------------------------------------------------------------------
# 内部服务接口
#   该接口仅限内网调用，通过请求头 X-Api-Token 校验
#   完整令牌由两段拼接而成（后半段由接口自行返回）
# ------------------------------------------------------------------
INTERNAL_API = "/l6/api/internal/keys"
API_TOKEN_PART1 = "ZW1-API-TOKEN-2024-A1B2"       # 前半段
# API_TOKEN_PART2 由接口返回，不在配置中留存

CLOUD = {
    "provider": "政务云",
    "region": "cn-east-1",
}

OA_PORTAL = "http://oa.zwfw.internal/"
ADMIN_IP = "10.12.34.51"
MAINTAINER = "运维保障组 <ops@zwfw.gov.cn>"
ARCHIVED_AT = "2024-03-08"
